import{j as e,N as t}from"./vendor-react-CdjbBmnx.js";function a(){return e.jsx(t,{to:"/help",replace:!0})}export{a as default};
